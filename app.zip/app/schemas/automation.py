from pydantic import BaseModel
from typing import Dict, Any
from datetime import datetime


class AutomationRuleCreate(BaseModel):
    instagram_account_id: int
    trigger_type: str
    action_type: str
    config: Dict[str, Any]


class AutomationRuleUpdate(BaseModel):
    trigger_type: str | None = None
    action_type: str | None = None
    config: Dict[str, Any] | None = None
    is_active: bool | None = None


class AutomationRuleResponse(BaseModel):
    id: int
    instagram_account_id: int
    trigger_type: str
    action_type: str
    config: Dict[str, Any]
    is_active: bool
    created_at: datetime

    class Config:
        from_attributes = True
