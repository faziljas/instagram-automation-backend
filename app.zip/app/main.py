from dotenv import load_dotenv
load_dotenv()

from fastapi import FastAPI
from app.api.routes import auth, instagram, automation, webhooks

app = FastAPI(title="Instagram Automation SaaS")

# Register routers
app.include_router(auth.router, prefix="/auth", tags=["Auth"])
app.include_router(instagram.router, prefix="/api/instagram", tags=["Instagram"])
app.include_router(automation.router, prefix="/automation", tags=["Automation"])
app.include_router(webhooks.router, prefix="/webhooks", tags=["Webhooks"])
